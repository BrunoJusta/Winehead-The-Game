<template>
    <div>
        <RegisterForm/>
    </div>
</template>

<script>
    import RegisterForm from "../components/RegisterForm.vue"
    export default {
        name: "register",
        components:{
            RegisterForm
        }
    }
</script>

<style lang="scss" scoped>

</style>